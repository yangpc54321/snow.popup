(function () {
    addScript('js/inject.js');
})();


function addScript(filePath) {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL(filePath);
    s.onload = function () {
        var script = document.createElement('script');
        script.textContent = 'snuSettingsAdded()';
        (document.head || document.documentElement).appendChild(script);
    };

    (document.head || document.documentElement).appendChild(s);
}

//get an instance independent sync parameter
// function getFromSyncStorageGlobal(theName, callback) {
//     chrome.storage.sync.get(theName, function (result) {
//         callback(result[theName]);
//     });
// }
