var jfla_sndevtools_popup = angular.module('JFLA.SNDEVTOOLS.POPUP', []);
angular
  .module('JFLA.SNDEVTOOLS.POPUP')
  .config(
    [
      '$compileProvider',
      function ($compileProvider) {
        $compileProvider
          .aHrefSanitizationWhitelist(/^\s*(https?|chrome-extension):/);
      }
    ]);
angular.module('JFLA.SNDEVTOOLS.POPUP').controller('JFLA.SNDEVTOOLS.POPUP.CTRL',
  function ($scope) {
    $scope.tab_selected = 'jfla_session';
    $scope.show_tables_filter = false;
    $scope.show_updates_filter = false;

    $scope.table_result_arr = [];

    $scope.recent_updates_arr = [];

    $scope.server_nodes_arr = [];

    $scope.update_set = {
      error: true,
      loading: true
    };
    $scope.find_table = {
      loading: false,
      error: true,
    };
    $scope.recent_updates = {
      error: true,
      loading: true
    };
    $scope.server_nodes = {
      error: true,
      loading: true
    };
    $scope.user = {};

    getCurrentURL(function (tabURL) {
      $scope.listURL = parseListURL(unpackURL(tabURL));
      $scope.recordURL = parseRecordURL(unpackURL(tabURL));
      $scope.plainURL = unpackURL(tabURL);
      var foundTiny = $scope.plainURL.match(/^(https:\/\/[a-zA-Z0-9.-]*\/)([a-zA-Z0-9_-]+)\.do.*[&\?]sysparm_tiny=([^&]*)/);
      var foundUI15 = $scope.plainURL.match(/^(https:\/\/[a-zA-Z0-9.-]*\/)navpage\.do.*/);
      $scope.tinyURL = !!foundTiny;
      $scope.ui15URL = !!foundUI15;
      $scope.tabURL = tabURL;
      if ($scope.listURL || $scope.recordURL) {
        $scope.table = ($scope.listURL || $scope.recordURL).table;
      }
    });

    $scope.select_tab = function (jfla) {
      $scope.tab_selected = jfla;
      if (jfla == 'jfla_session') {
        $scope.show_tables_filter = false;
        $scope.show_updates_filter = false;
      }
      if (jfla == 'jfla_table') {
        $scope.show_tables_filter = true;
        $scope.show_updates_filter = false;
        getCurrentURL(initSearchTableHanedler);
      }
      if (jfla == 'jfla_update') {
        $scope.show_tables_filter = false;
        $scope.show_updates_filter = true;
        if ($scope.recent_updates_arr.length != 0) {
          return;
        }

        getCurrentURL(getLastChanges);
      }
      if (jfla == 'jfla_nodes') {
        $scope.show_tables_filter = false;
        $scope.show_updates_filter = false;
        if ($scope.server_nodes_arr.length != 0) {
          return;
        }
        getCurrentURL(getNodes);
      }
    }

    $scope.open_snow = function (page, target_self) {
      getCurrentURL(function (tabURL) {
        var url = tabURL.replace(
          /(https:\/\/[a-zA-Z0-9.-]*)\/.*/,
          "$1/" + page);
        if (target_self)
          refreshURL(url);
        else
          openNewTab(url);
      });
    }

    $scope.open_xml_page = function (url) {
      if (!$scope.listURL && !$scope.recordURL) {
        return;
      }
      openNewTab(url);
    }

    $scope.open_search_table_page = function (page, transform) {
      if (!$scope.user.loading && !$scope.user.sys_id) {
        return;
      }
      if (!transform) {
        openTab(chrome.runtime.getURL("/" + page))();
        return;
      }
      getCurrentURL(function (tabURL) {
        var params = tabURL.replace(
          /(https:\/\/[a-zA-Z0-9.-]*)\/(.*)/, transform);
        openTab(chrome.runtime.getURL("/" + page + "?" + encodeURIComponent(params)))();
      });
    }

    function getCurrentUpdSet(tabURL) {
      $scope.update_set.loading = true;
      $scope.update_set.error = false;
      $scope.$apply();
      var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
      if (!isSNOWURL(tabURL) || (foundURL == null)) {
        $scope.update_set.error = true;
        $scope.update_set.loading = false;
        return;
      }

      getRecordData(foundURL[0] + 'sys_user_preference_list.do?sysparm_query=name%3Dsys_update_set%5EuserDYNAMIC90d1921e5f510100a9ad2572f2b477fe', function (url, rows) {
        if (rows == null) {
          $scope.update_set.loading = false;
          $scope.update_set.error = true;
          $scope.$apply();
          return;
        }
        if (!rows.length) {
          $scope.update_set.loading = false;
          $scope.update_set.error = true;
          $scope.$apply();
          return;
        }

        var sys_id = rows[0].value;
        $scope.update_set.sys_id = sys_id;
        $scope.update_set.name = sys_id;
        getRecordDataCSV(foundURL[0] + 'sys_update_set.do?sys_id=' + sys_id, function (url, rows) {
          if (rows == null) {
            $scope.update_set.loading = false;
            $scope.update_set.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.update_set.loading = false;
            $scope.update_set.error = true;
            $scope.$apply();
            return;
          }
          $scope.update_set = rows[0];
          $scope.update_set.loading = false;
          $scope.update_set.error = false;
          $scope.$apply();
        }, null, 1, "sys_id,name,is_default,application.name,application.scope,application.sys_id");
        $scope.$apply();
      }, null, 1);
    }
    getCurrentURL(getCurrentUpdSet);

    getCurrentUser = function (tabURL) {
      $scope.user.loading = true;
      $scope.user.error = false;
      $scope.$apply();
      var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
      if (!isSNOWURL(tabURL) || (foundURL == null)) {
        $scope.user.loading = false;
        $scope.user.error = true;
        $scope.$apply();
        return;
      }

      getRecordData(foundURL[0] + 'sys_user.do?sys_id=javascript:%20gs.getUserID()', function (url, rows, params) {
        if (rows == null) {
          $scope.user.loading = false;
          $scope.user.error = true;
          $scope.$apply();
          return;
        }
        if (!rows.length) {
          $scope.user.loading = false;
          $scope.user.error = true;
          $scope.$apply();
          return;
        }
        $scope.user = rows[0];
        getRecordData(params + 'sys_user_list.do?sysparm_query=sys_id=' + $scope.user.sys_id + "^roles=admin", function (url, rows) {
          if (rows == null || !rows.length || rows.length == 0) {
            $scope.user.roles = null;
          } else {
            $scope.user.roles = "admin";
          }
          $scope.$apply();
        });
        $scope.user.loading = false;
        $scope.user.error = false;
        $scope.$apply();
      }, foundURL[0], 1);
    }
    getCurrentURL(getCurrentUser);

    getLastChanges = function (tabURL) {
      $scope.recent_updates.loading = true;
      $scope.recent_updates.error = false;
      $scope.$apply();
      var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
      if (!isSNOWURL(tabURL) || (foundURL == null)) {
        $scope.recent_updates.loading = false;
        $scope.recent_updates.error = true;
        $scope.$apply();
        return;
      }

      getRecordData(foundURL[0] + 'sys_update_version_list.do?sysparm_query=ORDERBYDESCsys_created_on^state=current^sys_created_by%3Djavascript:%20gs.getUserName()', function (url, rows, url) {
        if (rows == null) {
          $scope.recent_updates.loading = false;
          $scope.recent_updates.error = true;
          $scope.$apply();
          return;
        }
        if (!rows.length) {
          $scope.recent_updates.loading = false;
          $scope.recent_updates.error = true;
          $scope.$apply();
          return;
        }
        $scope.recent_updates = rows;
        $scope.recent_updates.loading = false;
        $scope.recent_updates.error = false;
        var upd_sets = rows.map(v => v.source).filter((elem, pos, arr) => (arr.indexOf(elem) == pos));
        getRecordData(url + 'sys_update_set_list.do?sysparm_query=sys_idIN' + upd_sets.join(),
          function (url, rows) {
            if (rows == null) {
              return;
            }
            if (!rows.length) {
              return;
            }
            var upd_sets = {};
            rows.forEach(v => upd_sets[v.sys_id] = v);

            $scope.recent_updates.forEach(function (v) {
              $scope.recent_updates_arr.push({
                type: v.type,
                name: v.name,
                record_name: v.record_name,
                sys_created_on: v.sys_created_on,
                source: upd_sets[v.source]
              });
            });

            $scope.$apply();
          }, null, 30);

        $scope.$apply();
      }, foundURL[0], 30, "source,sys_created_on,name,record_name,type");
    }

    getNodes = function (tabURL) {
      $scope.server_nodes.loading = true;
      $scope.server_nodes.error = false;
      $scope.$apply();
      var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
      if (!isSNOWURL(tabURL) || (foundURL == null)) {
        $scope.server_nodes.loading = false;
        $scope.server_nodes.error = true;
        $scope.$apply();
        return;
      }

      getRecordDataCSV(foundURL[0] + 'sys_cluster_state_list.do?sysparm_query', function (url, rows, url) {
        if (rows == null) {
          $scope.server_nodes.loading = false;
          $scope.server_nodes.error = true;
          $scope.$apply();
          return;
        }
        if (!rows.length) {
          $scope.server_nodes.loading = false;
          $scope.server_nodes.error = true;
          $scope.$apply();
          return;
        }
        $scope.server_nodes_arr = rows;
        $scope.server_nodes.loading = false;
        $scope.server_nodes.error = false;
        $scope.$apply();
      }, foundURL[0], 8, "sys_id,system_id,status");
    }

    initSearchTableHanedler = function (tabURL) {
      var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
      $scope.$watch('table_filter', function (nValue, oValue) {
        if (nValue == oValue) {
          return;
        }
        $scope.find_table.loading = true;

        var query = encodeURI($scope.table_filter);

        if (!$scope.table_filter || query.length < 3) {
          $scope.find_table.loading = false;
          return;
        }

        var url = foundURL[0] + "sys_db_object.do?JSONv2&sysparm_query=ORDERBYlabel^nameLIKE" + query + "%5EORlabelLIKE" + query + "&displayvalue=true";
        var regexp = /[0-9a-f]{32}/;
        getRecordDataFromJsonWebService(url, function (url, rows) {
          $scope.table_result_arr = [];
          if (!rows) {
            $scope.find_table.loading = false;
            $scope.find_table.error = true;
            $scope.$apply();
            return;
          }

          rows.forEach(function (v) {
            $scope.table_result_arr.push({
              label: v.label,
              name: v.name,
              super_class: v.super_class ? v.super_class : '-',
              // super_class_sys_id: v.super_class ? v.super_class.link.match(regexp) : 'null',
              sys_scope: v.sys_scope ? v.sys_scope : '-',
              // sys_scope_sys_id: v.sys_scope ? v.sys_scope.link.match(regexp) : 'null',
              sys_id: v.sys_id
            });
          });
          $scope.find_table.loading = false;
          $scope.find_table.error = false;
          $scope.$apply();
        }, {}, 10000, "sys_id,name,label,super_class,sys_scope");
      }, true);
    };

    // updates sort property
    $scope.updateSortPropertyName = 'sys_created_on';
    // desc
    $scope.update_reverse = true;

    $scope.sortByForUpdate = function (propertyName) {
      $scope.update_reverse = ($scope.updateSortPropertyName === propertyName) ? !$scope.update_reverse : false;
      $scope.updateSortPropertyName = propertyName;
    };

    // table sort property
    $scope.tableSortPropertyName = 'label';
    // desc
    $scope.table_reverse = true;

    $scope.sortByForTable = function (propertyName) {
      $scope.table_reverse = ($scope.tableSortPropertyName === propertyName) ? !$scope.table_reverse : false;
      $scope.tableSortPropertyName = propertyName;
    };

    // node sort property
    $scope.nodeSortPropertyName = 'system_id';
    // desc
    $scope.node_reverse = true;

    $scope.sortByForNode = function (propertyName) {
      $scope.node_reverse = ($scope.nodeSortPropertyName === propertyName) ? !$scope.node_reverse : false;
      $scope.nodeSortPropertyName = propertyName;
    };

    $scope.popup = function (url) {
      pop();
    }
  });