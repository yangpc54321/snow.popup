var y_servicenow_popup = angular.module('y.servicenow.popup', []);
angular
  .module('y.servicenow.popup')
  .config(
    [
      '$compileProvider',
      function ($compileProvider) {
        $compileProvider
          .aHrefSanitizationWhitelist(/^\s*(https?|chrome-extension):/);
      }
    ]);
angular
  .module('y.servicenow.popup')
  .controller(
    'PopupCtrl',
    function ($scope, $http) {
      $http.get("jsondata/client.json")
        .then(function (res) {
          $scope.client_contents = res.data;
        });

      $http.get("jsondata/rest.json")
        .then(function (res) {
          $scope.rest_contents = res.data;
        });

      $http.get("jsondata/server_scoped.json")
        .then(function (res) {
          $scope.server_scoped_contents = res.data;
        });

      $http.get("jsondata/server_global.json")
        .then(function (res) {
          $scope.server_global_contents = res.data;
        });

      $scope.hide_search_api_input = function () {
        $(".edit_api_input").show();
        $(".search_api_input").hide();
      }

      $scope.show_search_api_input = function () {
        $(".edit_api_input").hide();
        $(".search_api_input").show();
      }

      $scope.jfla_selected = 'jfla_home';
      $scope.sub_jfla_selected = 'jfla_api_client';

      $scope.update_set = {};
      $scope.recent_changes = {
        error: true,
        loading: true
      };
      $scope.hide_row = {
        error: true,
        loading: true
      };
      $scope.server_nodes = {
        error: true,
        loading: true
      };
      $scope.server_stats = {
        error: true,
        loading: true
      };
      $scope.domain = {};
      $scope.user = {};
      $scope.environments = [];
      $scope.polling = false;
      $scope.polling_enabled = false;
      $scope.customScripts = [];
      $scope.customScriptsTip = true;

      var scriptsChanged = function (newValue, oldValue, scope) {
        for (var i in $scope.customScripts) {
          for (var p in $scope.customScripts[i].params) {
            var parm_name = $scope.customScripts[i].params[p];
            if ((parm_name == "sys_id") || (parm_name == "sysparm_query") || (parm_name == "sys_class_name")) {
              $scope.customScriptsTip = false;
            }
          }
        }
        if ($scope.customScripts.length > 0 && ($scope.listURL || $scope.recordURL)) {
          var sys_id = "";
          var sysparm_query = "";
          var sys_class_name = "";

          if ($scope.listURL) {
            sysparm_query = $scope.listURL.query;
            sys_class_name = $scope.listURL.table;
          }
          if ($scope.recordURL) {
            sys_id = $scope.recordURL.sys_id;
            sysparm_query = "sys_id=" + $scope.recordURL.sys_id;
            sys_class_name = $scope.recordURL.table;
          }

          for (var i in $scope.customScripts) {
            $scope.customScripts[i].values = {};
            for (var p in $scope.customScripts[i].params) {
              var parm_name = $scope.customScripts[i].params[p];
              if (parm_name == "sys_id") {
                $scope.customScripts[i].values[parm_name] = sys_id;
              } else if (parm_name == "sysparm_query") {
                $scope.customScripts[i].values[parm_name] = sysparm_query;
              } else if (parm_name == "sys_class_name") {
                $scope.customScripts[i].values[parm_name] = sys_class_name;
              }
            }
          }
        }
      };
      $scope.$watch('recordURL', scriptsChanged);
      $scope.$watch('customScripts', scriptsChanged);

      getCurrentURL(function (tabURL) {
        $scope.listURL = parseListURL(unpackURL(tabURL));
        $scope.recordURL = parseRecordURL(unpackURL(tabURL));
        $scope.plainURL = unpackURL(tabURL);
        var foundTiny = $scope.plainURL.match(/^(https:\/\/[a-zA-Z0-9.-]*\/)([a-zA-Z0-9_-]+)\.do.*[&\?]sysparm_tiny=([^&]*)/);
        var foundUI15 = $scope.plainURL.match(/^(https:\/\/[a-zA-Z0-9.-]*\/)navpage\.do.*/);
        $scope.tinyURL = !!foundTiny;
        $scope.ui15URL = !!foundUI15;
        $scope.tabURL = tabURL;
        if ($scope.listURL || $scope.recordURL) {
          $scope.table = ($scope.listURL || $scope.recordURL).table;
        }
      });

      getCurrentTab(function (tab) {

      });

      $scope.select_jfla = function (jfla) {
        $scope.jfla_selected = jfla;
        if (jfla == 'jfla_dev') {
          getCurrentURL(getLastChanges);
        }
        if (jfla == 'jfla_infra') {
          getCurrentURL(getNodes);
        }
      }

      $scope.select_sub_jfla = function (sub_jfla) {
        $scope.sub_jfla_selected = sub_jfla;
        if (sub_jfla == 'jfla_api_client') {
          // todo;
        }
      }

      $scope.openRunScript = function (script, parameters) {
        return function () {
          getCurrentURL(function (tabURL) {
            if (!isSNOWURL(tabURL))
              return;
            var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
            if (foundURL == null) {
              return;
            }
            openNewTab(chrome.runtime.getURL("/run_sys_scripts.html?url=" + foundURL[0] + "&script=" + script + (parameters ? ("&params=" + encodeURIComponent(JSON.stringify(parameters))) : "")));
          });
        }
      }

      $scope.runScript = function (script, mode) {
        if (!script.values) script.values = {};
        getCurrentURL(function (tabURL) {
          if (!isSNOWURL(tabURL))
            return;
          var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
          if (foundURL == null) {
            return;
          }
          if (script.params)
            for (var param in script.params) {
              if (!script.values[script.params[param]]) script.values[script.params[param]] = "";
            }
          openNewTab(chrome.runtime.getURL("/run_sys_scripts.html?url=" + foundURL[0] + "&mode=" + mode + "&customscript=" + script.name + "&params=" + encodeURIComponent(JSON.stringify(script.values))));
        });
      }

      $scope.paste_on = function () {
        document.getElementById('servicenow_clipboard_wrapper').classList.remove('hidden');
        document.getElementById('servicenow_clipboard_wrapper').focus();
      }

      $scope.paste_off = function () {
        document.getElementById('servicenow_clipboard_wrapper').classList.add('hidden');
      }

      $scope.do_paste = function (event) {
        var content = event.clipboardData;
        if (content.items.length <= 0) {
          $scope.paste_off();
          return;
        }
        for (var i = 0; i < content.items.length; i++) {
          var type = content.items[i].type;
          var fr = new FileReader();
          var file = content.items[i].getAsFile();
          console.log(file);
          fr.onload = e => {
            var file = new Blob([fr.result], {
              type: type
            });
            getCurrentURL(function (tabURL) {
              var foundURL = parseRecordURL(unpackURL(tabURL));
              if (!foundURL) {
                return;
              }
              var xhr = new XMLHttpRequest();
              xhr.withCredentials = true;
              xhr.onreadystatechange = function () {
                console.log(xhr);
              }
              xhr.open("POST", foundURL.host + 'attachment.do');
              xhr.setRequestHeader('Referer', unpackURL(tabURL));
              xhr.send(file);
            });
          };
          fr.readAsArrayBuffer(file);
        }
      };

      $scope.openGlideRecord = function () {
        if (!$scope.listURL && !$scope.recordURL)
          return;
        getCurrentURL(function (tabURL) {
          var url = chrome.runtime.getURL("glideRecord.html?" +
            encodeURIComponent(tabURL));
          window.close();
          openNewTab(url);
        });
      }

      $scope.open_snow = function (page, target_self) {
        getCurrentURL(function (tabURL) {
          var url = tabURL.replace(
            /(https:\/\/[a-zA-Z0-9.-]*)\/.*/,
            "$1/" + page);
          if (target_self)
            refreshURL(url);
          else
            openNewTab(url);
        });
      }

      $scope.do_global_search = function (page) {
        getCurrentURL(function (tabURL) {
          var url = tabURL.replace(
            /(https:\/\/[a-zA-Z0-9.-]*)\/.*/,
            "$1/" + page + '?sysparm_search=' + $scope.search_parameter);
          openNewTab(url);
        });
      }

      $scope.open_xml_page = function (url) {
        if (!$scope.listURL && !$scope.recordURL) {
          return;
        }
        openNewTab(url);
      }

      $scope.open_page = function (url) {
        openNewTab(url);
      }

      $scope.open_servicenow = function (page, transform) {
        if (!$scope.user.loading && !$scope.user.sys_id) {
          return;
        }
        if (!transform) {
          openTab(chrome.runtime.getURL("/" + page))();
          return;
        }
        getCurrentURL(function (tabURL) {
          var params = tabURL.replace(
            /(https:\/\/[a-zA-Z0-9.-]*)\/(.*)/, transform);
          openTab(chrome.runtime.getURL("/" + page + "?" + encodeURIComponent(params)))();
        });
      }

      function getCurrentUpdSet(tabURL) {
        $scope.update_set.loading = true;
        $scope.update_set.error = false;
        $scope.$apply();
        var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
        if (!isSNOWURL(tabURL) || (foundURL == null)) {
          $scope.update_set.error = true;
          $scope.update_set.loading = false;
          return;
        }

        getRecordData(foundURL[0] + 'sys_user_preference_list.do?sysparm_query=name%3Dsys_update_set%5EuserDYNAMIC90d1921e5f510100a9ad2572f2b477fe', function (url, rows) {
          if (rows == null) {
            $scope.update_set.loading = false;
            $scope.update_set.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.update_set.loading = false;
            $scope.update_set.error = true;
            $scope.$apply();
            return;
          }
          //'sys_update_set.do?XML&sys_id=' + updateSet.sysId
          var sys_id = rows[0].value;
          $scope.update_set.sys_id = sys_id;
          $scope.update_set.name = sys_id;
          getRecordDataCSV(foundURL[0] + 'sys_update_set.do?sys_id=' + sys_id, function (url, rows) {
            if (rows == null) {
              $scope.update_set.loading = false;
              $scope.update_set.error = true;
              $scope.$apply();
              return;
            }
            if (!rows.length) {
              $scope.update_set.loading = false;
              $scope.update_set.error = true;
              $scope.$apply();
              return;
            }
            $scope.update_set = rows[0];
            //console.log($scope.update_set);
            $scope.update_set.loading = false;
            $scope.update_set.error = false;
            $scope.$apply();
          }, null, 1, "sys_id,name,is_default,application.name,application.scope,application.sys_id");
          $scope.$apply();
        }, null, 1);
      }
      getCurrentURL(getCurrentUpdSet);

      getCurrentDomain = function (tabURL) {
        $scope.domain.loading = true;
        $scope.domain.error = false;
        $scope.$apply();
        var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
        if (!isSNOWURL(tabURL) || (foundURL == null)) {
          $scope.domain.loading = false;
          $scope.domain.error = true;
          return;
        }
        getRecordData(foundURL[0] + 'domain.do?sys_id=javascript:gs.getUser().getDomainID()', function (url, rows) {
          if (rows == null) {
            $scope.domain.loading = false;
            $scope.domain.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.domain.loading = false;
            $scope.domain.error = false;
            //$scope.domain.name = "global";
            $scope.$apply();
            return;
          }
          $scope.domain = rows[0];
          $scope.domain.loading = false;
          $scope.domain.error = false;
          $scope.$apply();
        }, null, 1);
      }
      getCurrentURL(getCurrentDomain);

      getCurrentUser = function (tabURL) {
        $scope.user.loading = true;
        $scope.user.error = false;
        $scope.$apply();
        var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
        if (!isSNOWURL(tabURL) || (foundURL == null)) {
          $scope.user.loading = false;
          $scope.user.error = true;
          $scope.$apply();
          return;
        }

        getRecordData(foundURL[0] + 'sys_user.do?sys_id=javascript:%20gs.getUserID()', function (url, rows, params) {
          if (rows == null) {
            $scope.user.loading = false;
            $scope.user.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.user.loading = false;
            $scope.user.error = true;
            $scope.$apply();
            return;
          }
          $scope.user = rows[0];
          getRecordData(params + 'sys_user_list.do?sysparm_query=sys_id=' + $scope.user.sys_id + "^roles=admin", function (url, rows) {
            if (rows == null || !rows.length || rows.length == 0) {
              $scope.user.roles = null;
            } else {
              $scope.user.roles = "admin";
            }
            $scope.$apply();
          });
          $scope.user.loading = false;
          $scope.user.error = false;
          $scope.$apply();
        }, foundURL[0], 1);
      }
      getCurrentURL(getCurrentUser);

      getLastChanges = function (tabURL) {
        $scope.recent_changes.loading = true;
        $scope.recent_changes.error = false;
        $scope.$apply();
        var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
        if (!isSNOWURL(tabURL) || (foundURL == null)) {
          $scope.recent_changes.loading = false;
          $scope.recent_changes.error = true;
          $scope.$apply();
          return;
        }

        getRecordData(foundURL[0] + 'sys_update_version_list.do?sysparm_query=ORDERBYDESCsys_created_on^state=current^type!=Access Roles^sys_created_by%3Djavascript:%20gs.getUserName()', function (url, rows, url) {
          if (rows == null) {
            $scope.recent_changes.loading = false;
            $scope.recent_changes.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.recent_changes.loading = false;
            $scope.recent_changes.error = true;
            $scope.$apply();
            return;
          }
          $scope.recent_changes = rows;
          $scope.recent_changes.loading = false;
          $scope.recent_changes.error = false;
          var upd_sets = rows.map(v => v.source).filter((elem, pos, arr) => (arr.indexOf(elem) == pos));
          getRecordData(url + 'sys_update_set_list.do?sysparm_query=sys_idIN' + upd_sets.join(),
            function (url, rows) {
              if (rows == null) {
                return;
              }
              if (!rows.length) {
                return;
              }
              var upd_sets = {};
              rows.forEach(v => upd_sets[v.sys_id] = v);
              $scope.recent_changes.forEach(v => (v.source = upd_sets[v.source]));
              $scope.$apply();
            }, null, 30);

          $scope.$apply();
        }, foundURL[0], 50, "source,sys_created_on,name,record_name,type");
      }

      getNodes = function (tabURL) {
        $scope.server_nodes.loading = true;
        $scope.server_nodes.error = false;
        $scope.$apply();
        var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
        if (!isSNOWURL(tabURL) || (foundURL == null)) {
          $scope.server_nodes.loading = false;
          $scope.server_nodes.error = true;
          $scope.$apply();
          return;
        }

        getRecordDataCSV(foundURL[0] + 'sys_cluster_state_list.do?sysparm_query', function (url, rows, url) {
          if (rows == null) {
            $scope.server_nodes.loading = false;
            $scope.server_nodes.error = true;
            $scope.$apply();
            return;
          }
          if (!rows.length) {
            $scope.server_nodes.loading = false;
            $scope.server_nodes.error = true;
            $scope.$apply();
            return;
          }
          $scope.server_nodes = rows;
          $scope.server_nodes.loading = false;
          $scope.server_nodes.error = false;
          $scope.$apply();
        }, foundURL[0], 8, "sys_id,system_id,status");

        getXPathData(foundURL[0] + 'xmlstats.do?include=instance,memory,sessionsummary,scheduler,servlet',
          ['/xmlstats/sessionsummary/@total', '/xmlstats/system.memory.pct.free', '/xmlstats/servlet.started',
            '/xmlstats/servlet.node_id', '/xmlstats/instance_current_version'
          ],
          function (url, xml, params) {
            console.log(xml);
            if (xml == null) {
              $scope.server_stats.loading = false;
              $scope.server_stats.error = true;
              $scope.$apply();
              return;
            }
            if (!xml['/xmlstats/sessionsummary/@total']) {
              $scope.server_stats.loading = false;
              $scope.server_stats.error = true;
              $scope.$apply();
              return;
            }
            $scope.server_stats.params = xml;
            $scope.server_stats.loading = false;
            $scope.server_stats.error = false;
            $scope.$apply();
          }, foundURL[0]);
      }

      $scope.open_snow_remote_updset = function (envUrl, queryObj) {
        if (!queryObj.query)
          queryObj.query = 'sys_id=' + queryObj.sys_id;
        return function () {
          if (queryObj.table != 'sys_update_set') return;
          getRecordDataCSV(queryObj.host + 'sys_update_set.do?sysparm_query=' + queryObj.query, function (url, rows, url) {
            if (rows.length > 50) {
              alert('Due to URL length limit, this function can work for up to 50 update sets. Please apply more filters.');
              return;
            }
            var url = envUrl + 'sys_remote_update_set_list.do?sysparm_query=remote_sys_idIN' + rows.map(row => row.sys_id).join(',');
            openNewTab(url);
          }, null, 51, "sys_id");
        };
      };

      $scope.open_copy_updset = function (envUrl) {
        return function () {
          getCurrentURL(function (tabURL) {
            var foundURL = parseRecordURL(unpackURL(tabURL));
            if (foundURL) {
              if (foundURL.table != 'sys_update_set') return;
              var url = chrome.runtime.getURL("/compare_upd_sets.html?url1=" +
                foundURL.host + "&url2=" + envUrl + "&sysparm_query=sys_id=" + foundURL.sys_id);
              openNewTab(url);
            }
            foundURL = parseListURL(unpackURL(tabURL));
            if (foundURL) {
              if (foundURL.table != 'sys_update_set') return;
              var url = chrome.runtime.getURL("/compare_upd_sets.html?url1=" +
                foundURL.host + "&url2=" + envUrl + "&sysparm_query=" + foundURL.query);
              openNewTab(url);
            }
          });
        }
      };

      $scope.switch_node = function (node) {
        getCurrentURL(function (tabURL) {
          var foundURL = tabURL.match(/^https:\/\/[a-zA-Z0-9.-]*\//);
          if (!foundURL)
            return;
          var url = foundURL[0];
          chrome.cookies.get({
            url: url,
            name: 'glide_user_route'
          }, function (cookie) {
            if (cookie) {
              cookie.value = "glide." + node;
              chrome.cookies.set({
                url: url,
                name: cookie.name,
                value: cookie.value,
                path: cookie.path,
                secure: cookie.secure,
                httpOnly: cookie.httpOnly,
                sameSite: cookie.sameSite,
                expirationDate: cookie.expirationDate,
                storeId: cookie.storeId
              }, function (cookie) {
                if (cookie) {
                  chrome.cookies.getAll({
                    url: url
                  }, function (cookie) {
                    cookie = cookie.filter(c => c.name.startsWith('BIGipServerpool_')).forEach(c => {
                      chrome.cookies.remove({
                        url: url,
                        name: c.name
                      }, function (cookie) {
                        setTabURL(url + 'logout.do');
                        window.close();
                      });
                    });
                  });
                }
              });
            }
          });
        });
      };

      $scope.sort = {
        column: '-sys_created_on',
        descending: 'down'
      };

      $scope.changeTrClass = function (column) {
        if($scope.sort.descending == 'down' && $scope.sort.column == '-' + column){
          return 'glyphicon glyphicon-arrow-down';
        } else if ($scope.sort.descending == 'up' && $scope.sort.column == column){
          return 'th glyphicon glyphicon-arrow-up';
        } else {
          return '';
        }
      };

      $scope.sortBy = function (column) {
        var sort = $scope.sort;
        if (sort.column == '-' + column && sort.descending == 'down') {
          sort.descending = 'up';
          sort.column = column;
        }else if (sort.column == column && sort.descending == 'up') {
          sort.descending = 'down';
          sort.column = '-' + column;
        } else {
          sort.descending = 'up';
          sort.column = column;
        }
      };
    });