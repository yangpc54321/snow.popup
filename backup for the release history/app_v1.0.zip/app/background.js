function isSNOWURL(url) {
    var valid = (/^https:\/\/[a-zA-Z0-9.-]*\.service-now\.com\/.*/.test(url));
    return valid;
}

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (isSNOWURL(tab.url)) {
        chrome.pageAction.show(tabId);
        if (changeInfo.status != 'complete')
            return;
    }
});